package com.joel.productos_categorias.repositories;

import com.joel.productos_categorias.models.Producto;

public interface ProductoRepository extends BaseRepository<Producto>{
}

