package com.joel.productos_categorias.repositories;
import com.joel.productos_categorias.models.Categoria;

public interface CategoriaRepository extends BaseRepository<Categoria> {
    
}
