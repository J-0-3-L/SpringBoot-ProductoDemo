package com.joel.productos_categorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductosCategoriasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductosCategoriasApplication.class, args);
	}

}
