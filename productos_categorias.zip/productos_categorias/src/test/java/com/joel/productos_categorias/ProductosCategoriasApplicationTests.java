package com.joel.productos_categorias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductosCategoriasApplicationTests {

	@Test
	void contextLoads() {
	}

}
